﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ClassLibrary
{
    public class wordList
    {
        
        public static string Index(string directory)
        {
            Dictionary<string, List<string>> wordList = new Dictionary<string, List<string>>();

            // Directory containing text files to index
            string textDirectory = @"../../../ClassLibrary/Doc/wordText.txt";


            foreach (var filePath in textDirectory)
            {
                //var text = File.ReadAllText(filePath);
                var text = File.ReadAllText(filePath.ToString());
                string[] wordSplit = text.Split(new char[] { ' ', '\t', '\n', '\r', '.', ',', ';', '!', '?' }, StringSplitOptions.RemoveEmptyEntries);

                foreach (var word in wordSplit)
                {
                    string wordIndexed = word.Trim().ToLower();

                    if (!wordList.ContainsKey(wordIndexed))
                    {
                        wordList[wordIndexed] = new List<string>();
                    }

                    if (!wordList[wordIndexed].Contains(text))
                    {
                        wordList[wordIndexed].Add(text);
                    }
                }
            }
            return directory;
        }
    }
}
