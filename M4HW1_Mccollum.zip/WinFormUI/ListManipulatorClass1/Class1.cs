﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace ListManipulatorClass1
{
    public class Class1
    {
        public static List<int> listINT()
        {

            List<int> numbINT = new List<int>();
            
            using (StreamReader reader = File.OpenText(@"../../../ListManipulatorClass\Docs\numbers.txt"))
            {
                while (!reader.EndOfStream)
                {
                    numbINT.Add(int.Parse(reader.ReadLine()));
                }
            }

            return numbINT;
        }

        public static void NegativeINT(List<int> list)
        {
            Predicate<int> negativeINT = x => x < 0; 
            list.RemoveAll(negativeINT);
        }

        public static List<int> IntRange(List<int> list)
        {
            List<int> rangeList = new List<int>();

            Predicate<int> intRange = x => (x >= 1 && x <= 10);
            rangeList = list.FindAll(intRange);

            return rangeList;
        }
    }
}
