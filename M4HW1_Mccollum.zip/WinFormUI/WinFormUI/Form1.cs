﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using ClassLibrary;

/**
* Sept 21 23
* CSC 253
* McCollum Joseph
* This indexes all of the text in the file folder and counts how many spaces, words, and numbers in the program
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            richTextBox2.Clear();
        }

        private void enterBtn_Click(object sender, EventArgs e)
        {
            StreamReader inputText;

            inputText = File.OpenText(@"../../../ClassLibrary/Doc/wordText.txt");
            richTextBox1.Text = inputText.ReadToEnd();
        }

        private void countBtn_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = wordList.Index(@"../../../ClassLibrary/Doc/wordText.txt");

        }
    }
}
