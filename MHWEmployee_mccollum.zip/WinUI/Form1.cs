﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;

/**
* 9 25 23
* CSC 253
* Mccollum Joseph
* Program description
*/

namespace WinUI
{
    public partial class Form : System.Windows.Forms.Form
    {
        ShiftInfo employ = new ShiftInfo();

        public Form()
        {
            InitializeComponent();
        }

        private void EmployeeProperty()
        {
            //This outputs the Employee information in the property box
            nametextBox5.Text = employ.Name;
            IDtextBox6.Text = employ.IDnum.ToString();
            hourstextBox7.Text = employ.Shift.ToString();
            paytextBox8.Text = employ.PayRate.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            nametextBox1.Clear();
            nametextBox5.Clear();
            IDtextBox2.Clear();
            IDtextBox6.Clear();
            hourstextBox3.Clear();
            hourstextBox7.Clear();
            paytextBox8.Clear();
            paytextBox4.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EmployeeProperty();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
