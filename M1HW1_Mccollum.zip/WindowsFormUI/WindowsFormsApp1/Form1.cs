﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseClassLibrary;


/**
* 9/10/23
* CSC 253
* McCollum, Joseph
* This program contains dictionary information with course information/ meeting times/ instructor names. Prompts the user
* to enter the course information and then it will display the information in the dictionary. 
*/


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            courseBox.Clear();
            roomnumberBox.Clear();
            instructorBox.Clear();
            meetingtimeBox.Clear();
        }

        private void enterBtn_Click(object sender, EventArgs e)
        {   
            /**This pulls the information from the CourseClassLibrary dictionary if the user enters the wrong information the 
             * program will throw a error message 
            **/
            try
            {
                roomnumberBox.Text = Course.RoomNumber[courseBox.Text];
                instructorBox.Text = Course.InstructorName[courseBox.Text];
                meetingtimeBox.Text = Course.MeetingTime[courseBox.Text];
            }
            catch 
            {
                MessageBox.Show("Invalid input try again!");
            }
        }

    }
}
