﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;

/**
* Sept 25 23
* CSC 253
* Mccollum, Joseph
* This program takes input from a user from the inherited class and produces a output, if a user enters an invalid input it will reset
* the value for the shift is set for 3 shifts
* ****************************************************************
* Added Shift supervisor class to the program runs the same as the first with class inheritance and uses a Try/Catch statement to get valid input
* from the user
*/


namespace WindowsUI
{
    public partial class Form1 : Form
    {
        ProductionWorker employee = new ProductionWorker();
        ShiftSupervisor supervisor = new ShiftSupervisor();

        public Form1()
        {
            InitializeComponent();
        }

        private void EmployeeProperty()
        {
            //This outputs the Employee information in the property box
            textBox5.Text = employee.Name;
            textBox6.Text = employee.IDnum.ToString();
            textBox7.Text = employee.Shift.ToString();
            textBox8.Text = employee.PayRate.ToString("c");
        }

        private void SupervisorProp()
        {
            //This outputs for the Shift supervisor class 
            shiftNameOut.Text = supervisor.Name;
            shiftNumOut.Text = supervisor.IDnum.ToString();
            shiftProdOut.Text = supervisor.annualProduction.ToString("c");
            shiftSalOut.Text = supervisor.annualSalary.ToString("c");
        }
        private void resetBtn_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();            
        }

        private void enterBtn_Click(object sender, EventArgs e)
        {
            EmployeeProperty();
            try
            {
                employee.Name = textBox1.Text;
                employee.IDnum = int.Parse(textBox2.Text);
                employee.Shift = int.Parse(textBox3.Text);
                employee.PayRate = decimal.Parse(textBox4.Text);
                EmployeeProperty();

            }
            catch (Exception ex)
            {

                MessageBox.Show("Invalid Input!");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
            }
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            shiftName.Clear();
            shiftNum.Clear();
            shiftProd.Clear();
            shiftSal.Clear();
            
            shiftNameOut.Clear();
            shiftNumOut.Clear();
            shiftProdOut.Clear();
            shiftSalOut.Clear();
        }

        private void shiftBtn_Click(object sender, EventArgs e)
        {
            try
            {
                supervisor.Name = shiftName.Text;
                supervisor.IDnum = int.Parse(shiftNum.Text);
                supervisor.annualProduction = decimal.Parse(shiftProd.Text);
                supervisor.annualSalary =  decimal.Parse(shiftSal.Text);
                SupervisorProp();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Invalid Response Try again!");
                shiftName.Clear();
                shiftNum.Clear();
                shiftProd.Clear();
                shiftSal.Clear();

                shiftNameOut.Clear();
                shiftNumOut.Clear();
                shiftProdOut.Clear();
                shiftSalOut.Clear();
            }
        }
    }
}
