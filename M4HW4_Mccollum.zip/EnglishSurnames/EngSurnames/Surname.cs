﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EngSurnames
{
    public static class Surname
    {
        public static List<string> NameList()
        {
            List<string> names = new List<string>();

            using (StreamReader reader = File.OpenText(@"../../../EngSurnames/surenames.txt"))            
            {
                while (!reader.EndOfStream)
                {
                    names.Add(reader.ReadLine());
                }
            }
            return names;
        }

        public static List<string> NameFilter(List<string> names, int criterion)
        {
            return names.FindAll(x => x.Length > criterion);
        }

        public static List<string> ShortFilter(List<string> names, int criterion)
        {
            return names.FindAll(x => x.Length < criterion);
        }

        public static List<string> BeginFilter(List<string> names, string criterion)
        {

            Predicate<string> StartsWith = x =>
            {
                x = x.ToLower();
                criterion = criterion.ToLower();

                for (int i = 0; i < criterion.Length; i++)
                {
                    if (x[i] != criterion[i])
                    {
                        return false;
                    }
                }
                return true;
            };

            return names.FindAll(StartsWith);
        }
    }
}
