﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EngSurnames;

/**
* 11 10 23
* CSC 253
* Mccollum Joseph
* This program allows a user to filter through a name text list either Long,Short, or the name that starts with a specific character
* 
*/

namespace WindowsFormsUI
{
    public partial class Form1 : Form
    {
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int LPAR);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        const int WM_NCLBUTTONDOWN = 0xA1;
        const int HT_CAPTION = 0x2;

        private void windowMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        public Form1()
        {
            InitializeComponent();
            this.MouseDown += new MouseEventHandler(windowMove);

        }


        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void longBtn_Click(object sender, EventArgs e)
        {
            try
            {
                ListItems(listBox1, Surname.NameFilter(Surname.NameList(), int.Parse(textBox1.Text)));
            }
            catch
            {

                MessageBox.Show("Invalid input or no input\nTry again!");
            }
        }

        private void ListItems(ListBox listBox, List<string> names)
        {
            listBox.Items.Clear();
            foreach (string name in names)
            {
                listBox.Items.Add(name);
            }
        }

        private void shortBtn_Click(object sender, EventArgs e)
        {
            try
            {
                ListItems(listBox1, Surname.ShortFilter(Surname.NameList(), int.Parse(textBox2.Text)));
            }
            catch
            {
                MessageBox.Show("Invalid input or no input\nTry again!");
            }
        }

        private void beginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                ListItems(listBox1, Surname.BeginFilter(Surname.NameList(), textBox3.Text));
            }
            catch
            {
                MessageBox.Show("Invalid input or no input\nTry again!");
            }
        }

        private void startBtn_Click(object sender, EventArgs e)
        {
            ListItems(listBox1, Surname.NameList());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            listBox1.Items.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            listBox1.Items.Clear();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            listBox1.Items.Clear();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
