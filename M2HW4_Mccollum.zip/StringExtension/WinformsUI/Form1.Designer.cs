﻿
namespace WinformsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.chartextBox1 = new System.Windows.Forms.TextBox();
            this.datetextBox2 = new System.Windows.Forms.TextBox();
            this.phonetextBox3 = new System.Windows.Forms.TextBox();
            this.revtextBox4 = new System.Windows.Forms.TextBox();
            this.counttextBox5 = new System.Windows.Forms.TextBox();
            this.exitBtn = new System.Windows.Forms.Button();
            this.resetBtn = new System.Windows.Forms.Button();
            this.resetBtn2 = new System.Windows.Forms.Button();
            this.phnBtn = new System.Windows.Forms.Button();
            this.revBtn = new System.Windows.Forms.Button();
            this.cntBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(73, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Char:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Date:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 304);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 439);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "String Reverse:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 573);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Word Counter:";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(151, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(342, 87);
            this.richTextBox1.TabIndex = 5;
            this.richTextBox1.Text = "";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(151, 157);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(342, 87);
            this.richTextBox2.TabIndex = 6;
            this.richTextBox2.Text = "";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(151, 304);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(342, 87);
            this.richTextBox3.TabIndex = 7;
            this.richTextBox3.Text = "";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(151, 439);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(342, 87);
            this.richTextBox4.TabIndex = 8;
            this.richTextBox4.Text = "";
            // 
            // richTextBox5
            // 
            this.richTextBox5.Location = new System.Drawing.Point(151, 573);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(342, 87);
            this.richTextBox5.TabIndex = 9;
            this.richTextBox5.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(521, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 44);
            this.button1.TabIndex = 10;
            this.button1.Text = "Char";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(521, 157);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(142, 44);
            this.button2.TabIndex = 11;
            this.button2.Text = "Date Format";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(521, 304);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(142, 44);
            this.button3.TabIndex = 12;
            this.button3.Text = "Phone Number";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(521, 439);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(142, 44);
            this.button4.TabIndex = 13;
            this.button4.Text = "Reverse";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(521, 573);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(142, 44);
            this.button5.TabIndex = 14;
            this.button5.Text = "Count";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // chartextBox1
            // 
            this.chartextBox1.Location = new System.Drawing.Point(743, 73);
            this.chartextBox1.Name = "chartextBox1";
            this.chartextBox1.Size = new System.Drawing.Size(286, 26);
            this.chartextBox1.TabIndex = 15;
            // 
            // datetextBox2
            // 
            this.datetextBox2.Location = new System.Drawing.Point(743, 217);
            this.datetextBox2.Name = "datetextBox2";
            this.datetextBox2.Size = new System.Drawing.Size(286, 26);
            this.datetextBox2.TabIndex = 16;
            // 
            // phonetextBox3
            // 
            this.phonetextBox3.Location = new System.Drawing.Point(743, 364);
            this.phonetextBox3.Name = "phonetextBox3";
            this.phonetextBox3.Size = new System.Drawing.Size(286, 26);
            this.phonetextBox3.TabIndex = 17;
            // 
            // revtextBox4
            // 
            this.revtextBox4.Location = new System.Drawing.Point(743, 499);
            this.revtextBox4.Name = "revtextBox4";
            this.revtextBox4.Size = new System.Drawing.Size(286, 26);
            this.revtextBox4.TabIndex = 18;
            // 
            // counttextBox5
            // 
            this.counttextBox5.Location = new System.Drawing.Point(743, 633);
            this.counttextBox5.Name = "counttextBox5";
            this.counttextBox5.Size = new System.Drawing.Size(286, 26);
            this.counttextBox5.TabIndex = 19;
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(151, 690);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(878, 48);
            this.exitBtn.TabIndex = 20;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // resetBtn
            // 
            this.resetBtn.Location = new System.Drawing.Point(521, 62);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(142, 41);
            this.resetBtn.TabIndex = 21;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = true;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // resetBtn2
            // 
            this.resetBtn2.Location = new System.Drawing.Point(521, 201);
            this.resetBtn2.Name = "resetBtn2";
            this.resetBtn2.Size = new System.Drawing.Size(142, 42);
            this.resetBtn2.TabIndex = 22;
            this.resetBtn2.Text = "Reset";
            this.resetBtn2.UseVisualStyleBackColor = true;
            this.resetBtn2.Click += new System.EventHandler(this.resetBtn2_Click);
            // 
            // phnBtn
            // 
            this.phnBtn.Location = new System.Drawing.Point(521, 348);
            this.phnBtn.Name = "phnBtn";
            this.phnBtn.Size = new System.Drawing.Size(142, 42);
            this.phnBtn.TabIndex = 23;
            this.phnBtn.Text = "Reset";
            this.phnBtn.UseVisualStyleBackColor = true;
            // 
            // revBtn
            // 
            this.revBtn.Location = new System.Drawing.Point(521, 482);
            this.revBtn.Name = "revBtn";
            this.revBtn.Size = new System.Drawing.Size(142, 44);
            this.revBtn.TabIndex = 24;
            this.revBtn.Text = "Reset";
            this.revBtn.UseVisualStyleBackColor = true;
            this.revBtn.Click += new System.EventHandler(this.revBtn_Click);
            // 
            // cntBtn
            // 
            this.cntBtn.Location = new System.Drawing.Point(521, 617);
            this.cntBtn.Name = "cntBtn";
            this.cntBtn.Size = new System.Drawing.Size(142, 42);
            this.cntBtn.TabIndex = 25;
            this.cntBtn.Text = "Reset";
            this.cntBtn.UseVisualStyleBackColor = true;
            this.cntBtn.Click += new System.EventHandler(this.cntBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1076, 750);
            this.Controls.Add(this.cntBtn);
            this.Controls.Add(this.revBtn);
            this.Controls.Add(this.phnBtn);
            this.Controls.Add(this.resetBtn2);
            this.Controls.Add(this.resetBtn);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.counttextBox5);
            this.Controls.Add(this.revtextBox4);
            this.Controls.Add(this.phonetextBox3);
            this.Controls.Add(this.datetextBox2);
            this.Controls.Add(this.chartextBox1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBox5);
            this.Controls.Add(this.richTextBox4);
            this.Controls.Add(this.richTextBox3);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox chartextBox1;
        private System.Windows.Forms.TextBox datetextBox2;
        private System.Windows.Forms.TextBox phonetextBox3;
        private System.Windows.Forms.TextBox revtextBox4;
        private System.Windows.Forms.TextBox counttextBox5;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Button resetBtn;
        private System.Windows.Forms.Button resetBtn2;
        private System.Windows.Forms.Button phnBtn;
        private System.Windows.Forms.Button revBtn;
        private System.Windows.Forms.Button cntBtn;
    }
}

