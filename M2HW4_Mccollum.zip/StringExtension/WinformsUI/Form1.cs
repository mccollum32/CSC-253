﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StringExtention;

/**
* 10 4 23
* CSC 253
* McCollum Joseph
* This program converts Char, Strings, Formats Date input and count words, reverse the string inputs as well 
*/

namespace WinformsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            char [] oneChar = richTextBox1.Text.CharString();
            richTextBox1.Clear();
            try
            {
                int oneCharIndex = 0;
                foreach (char txt in oneChar)
                {
                    if (oneCharIndex == oneChar.Length - 1) chartextBox1.Text += txt.ToString();
                    else chartextBox1.Text += txt.ToString() + ", ";
                    oneCharIndex++;
                }
              
            }
            catch (Exception ex)
            {

                MessageBox.Show("Invalid input, try again");
            }           
        }


        private void resetBtn_Click(object sender, EventArgs e)
        {
            chartextBox1.Clear();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            string[] dateFormat = richTextBox2.Text.DateString();

            if (dateFormat == null) datetextBox2.Text = "Improper Date Format, try again";
            else
            {
                richTextBox2.Clear();
                for(int i = 0; i < dateFormat.Length; i++)
                {
                    switch (i)
                    {
                        case 0:
                            datetextBox2.Text += "Month" + dateFormat[i] + ",";
                            break;
                        case 1:
                            datetextBox2.Text += "Day" + dateFormat[i] + ",";
                            break;
                        case 2:
                            datetextBox2.Text += "Year" + dateFormat[i];
                            break;
                    }
                }
            }
        }

        private void resetBtn2_Click(object sender, EventArgs e)
        {
            datetextBox2.Clear();
            richTextBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string phoneNumber = richTextBox3.Text.PhoneString();

            phonetextBox3.Text = phoneNumber;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            revtextBox4.Text = richTextBox4.Text.ReverseString();
        }

        private void revBtn_Click(object sender, EventArgs e)
        {
            revtextBox4.Clear();
            richTextBox4.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int counter = richTextBox5.Text.WordCount();

            if (counter == -1) counttextBox5.Text = "Invalid Input";
            else counttextBox5.Text = counter.ToString();
        }

        private void cntBtn_Click(object sender, EventArgs e)
        {
            richTextBox5.Clear();
            counttextBox5.Clear();
        }
    }
}
