﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringExtention
{
    public static class Class1
    {
        public static char [] CharString(this string str)
        {
            char[] character = new char[str.Length];
            int index = 0;
            foreach (char c in str)
            {
                character[index] = c;
                index++;
            }

            return character;
        }


        public static string[] DateString(this string str)
        {
            if (str.Length != 10 || !str.Contains('/')) return null;
            return str.Split('/');
        }

        public static string PhoneString(this string str)
        {
            if (str.Length != 10) return "Number is invalid try again!";

            string phoneNumber = str;

            phoneNumber = phoneNumber.Insert(0, "(");
            phoneNumber = phoneNumber.Insert(4, ") ");
            phoneNumber = phoneNumber.Insert(9, "-");

            return phoneNumber;
        }

        public static string ReverseString(this string str)
        {
            string reverse = "";
            for (int i = str.Length; i > 0; i--)
            {
                reverse += str[i - 1];
            }
            return reverse;
        }
        
        public static int WordCount(this string str)
        {
            if (str.Contains("\n")) return -1;

            int count = 0;
            int charIndex = 0;
            foreach (char c in str)
            {
                if ((c == ' ' && charIndex != 0 && str[charIndex - 1] != ' ') || charIndex == str.Length - 1)
                {
                    count++;
                }
                charIndex++;
            }
            return count;
        }
    }
}
