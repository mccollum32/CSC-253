﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FileClassLibrary1;
using System.IO;



namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void encBtn_Click(object sender, EventArgs e)
        {
            StreamReader inputFile;
            cryption.Encrypt(@"..\..\..\FileClassLibrary1\Docs\TextFile1.txt", @"..\..\..\FileClassLibrary1\Docs\TextFile2.txt");
            inputFile = File.OpenText(@"..\..\..\FileClassLibrary1\Docs\TextFile1.txt");
            richTextBox1.Clear();
            richTextBox1.Text = inputFile.ReadToEnd();
            richTextBox1.Clear();

            inputFile.Close();
        }

        private void decBtn_Click(object sender, EventArgs e)
        {
            StreamReader inputFile;

            cryption.Decrypt(@"..\..\..\FileClassLibrary1\Docs\TextFile1.txt" , @"..\..\..\FileClassLibrary1\Docs\TextFile2.txt");
            inputFile = File.OpenText(@"..\..\..\FileClassLibrary1\Docs\TextFile2.txt");
            richTextBox2.Clear();
            richTextBox2.Text = inputFile.ReadToEnd();
            richTextBox2.Clear();

            inputFile.Close();
        }
    }
}
