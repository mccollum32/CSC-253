﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileClassLibrary1
{
    public class cryption
    {
        StreamReader textScrambleFile = File.OpenText(@"../../../WindowsFormsApp2/FileClassLibrary1/Docs/TextFile.txt");

        public static Dictionary<char, char> textScramble = new Dictionary<char, char>()
        {
            {'A','%'}, {'a','9'}, {'B','@'}, { 'b','-' }, {'C','#'} ,
            {'c','&'}, {'D','*'}, {'d','('}, {'E','>'} , {'e','<'}, {'F','|'}, {'f','y'},
            {'G', '/'}, {'g', '='}, {'H', '+'}, {'h', '~'}, {'I', '^'} , {'i' , '$'} , {'J', '}'} ,
            {'j', ']'},  {'K', '{'}, {'k', '}'}, {'L','1'}, {'l','8'}, {'M', '3'}, {'m','2'},
            {'N','7' }, {'n','6' }, {'O','5' }, {'o','4' } , {'P','0' }, {'p','b' } , {'Q','W'} ,
            {'q','x' } , {'R','n' }, {'r','j' }, {'S','e' }, {'s','q' }, {'T','h' }, {'t','u' },
            {'U','z' }, {'u','r'}, {'V','c' }, {'v','m' }, {'W','s' }, {'w','l' },{'X','G' },
            {'x','A' }, {'Y','V' } ,{'y','F' } ,{'Z','o' }, {'z','p' }
        };

        public static void Encrypt(string readText, string outText)
        {
            StreamReader readFile = File.OpenText(readText);
            StreamWriter writeFile = File.CreateText(outText);
            string text;

            while (!readFile.EndOfStream)
            {
                text = readFile.ReadLine();
                string outputLine = "";

                for (int i = 0; i < text.Length; i++)
                {
                    if (textScramble.ContainsKey(text[i]))
                    {
                        outputLine += text[text[i]];
                    }
                    else
                    {
                        outputLine += text[i];
                    }
                }

                writeFile.WriteLine(outputLine);

            }

            readFile.Close();
            writeFile.Close();
        }

        public static void Decrypt(string readText, string writeFile)
        {
            StreamReader inText = File.OpenText(readText);
            StreamWriter outText = File.CreateText(writeFile);
            string text;

            while (!inText.EndOfStream)
            {
                text = inText.ReadLine();
                string outputLine = "";
                char textLetter;

                for (int i = 0; i < text.Length; i++)
                {
                    if (textScramble.ContainsValue(text[i]))
                    {
                        foreach (var textScram in textScramble)
                        {
                            if (textScram.Value == text[i])
                            {
                                textLetter = textScram.Key;
                                outputLine += textLetter;
                                break;
                            }
                        }
                    }
                    else
                    {
                        outputLine += text[i]; 
                    }
                }
                outText.WriteLine(outputLine); 
            }
            inText.Close();
            outText.Close();
        }
    }
}
