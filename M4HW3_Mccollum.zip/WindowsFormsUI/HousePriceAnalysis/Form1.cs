﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HouseLibrary;

/**
 * 11 10 23
 * CSC 233
 * Mccollum Joseph
 * This program allows the user to enter numbers into the program and scans through the csv file within the ranges
 */


namespace HousePriceAnalysis
{
    public partial class Form1 : Form
    {
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int LPAR);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        const int WM_NCLBUTTONDOWN = 0xA1;
        const int HT_CAPTION = 0x2;

        private void windowMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        } 

        public Form1()
        {
            InitializeComponent();
            this.MouseDown += new MouseEventHandler(windowMove);

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ListBoxItems(ListBox listBox, List<HouseClass> houses)
        {
            listBox.Items.Clear();
            foreach (HouseClass house in houses) listBox.Items.Add(house);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                HouseResults(listBox1, AnalysisClass.HouseListed(), int.Parse(textBoxBEDin.Text), int.Parse(textBoxBEDout.Text), double.Parse(textBoxBathIn.Text), double.Parse(textBoxBathout.Text), int.Parse(textBoxSQin.Text), int.Parse(textBoxSQout.Text));
            }
            catch
            {
                MessageBox.Show("Invalid Input.\nTry again.");
            }
        }
        private static void HouseResults(ListBox listBox, List<HouseClass> houseList, int bedroomIn = -1, int bedroomOut = -1, double bathroomIn = -1.0, double bathroomOut = -1.0, int sqFtIn = -1, int sqFtOut = -1)
        {

            bool bedroomCheck = (bedroomIn < 0 || bedroomOut < 0) ? false : true;
            bool bathroomCheck = (bathroomIn < 0.0 || bathroomOut < 0.0) ? false : true;
            bool sqFtCheck = (sqFtIn < 0 || sqFtOut < 0) ? false : true;

            if (bedroomCheck == true)
            {
                houseList = houseList.FindAll(h => h.Bedrooms >= bedroomIn && h.Bedrooms <= bedroomOut);
            }

            if (bathroomCheck == true)
            {
                houseList = houseList.FindAll(h => h.Bedrooms >= bathroomIn && h.Bedrooms <= bathroomOut);
            }

            if (sqFtCheck == true)
            {
                houseList = houseList.FindAll(h => h.SquareFeet >= sqFtIn && h.SquareFeet <= sqFtOut);
            }

            listBox.Items.Clear();
            foreach (HouseClass house in houseList) listBox.Items.Add("Price: " + house.Price.ToString("c") + ",  Bedrooms: " + house.Bedrooms.ToString() + ",  Bathrooms: " + house.Bedrooms.ToString() + ",  Square Feet: " + house.SquareFeet.ToString());

        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            textBoxBEDin.Clear();
            textBoxBEDout.Clear();
            textBoxBathIn.Clear();
            textBoxBathout.Clear();
            textBoxSQin.Clear();
            textBoxSQout.Clear();
        }
    }
}
