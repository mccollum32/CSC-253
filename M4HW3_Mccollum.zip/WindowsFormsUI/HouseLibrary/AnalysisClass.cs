﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseLibrary
{
    public static class AnalysisClass
    {
        public static List<HouseClass> HouseListed()
        {
            List<HouseClass> houseListed = new List<HouseClass>();

            int index = 0;

            using (StreamReader reader = File.OpenText(@"../../../HouseLibrary/house_prices.csv"))
            {
                while (!reader.EndOfStream)
                {
                    string[] splitters = reader.ReadLine().Split(',');

                    houseListed.Add(new HouseClass(int.Parse(splitters[0]), int.Parse(splitters[1]), double.Parse(splitters[2]), int.Parse(splitters[3])));
                    index++;
                }
            }

            return houseListed;

        }
    }
}
