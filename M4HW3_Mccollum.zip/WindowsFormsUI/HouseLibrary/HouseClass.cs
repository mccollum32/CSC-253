﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseLibrary
{
    public class HouseClass
    {
        public int Price { get; set; }
        public int Bedrooms { get; set; }
        public double Bathrooms { get; set; } 
        public int SquareFeet { get; set; }

        
        public HouseClass() { } 

        public HouseClass(int housePrice, int houseBedroom, double houseBathroom, int houseSquareFeet)
        {
            Price = housePrice;
            Bedrooms = houseBedroom;
            Bathrooms = houseBedroom;
            SquareFeet = houseSquareFeet;
        }
    }
}
