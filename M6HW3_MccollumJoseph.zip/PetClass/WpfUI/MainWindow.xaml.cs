﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PetLib1;

namespace WpfUI
{
    /**
    * 12 16 23
    * CSC 253
    * McCollum, Joseph
    * This program allows a user to enter a pets Name/Type/Age and then display the information to the user
    */

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void confirmButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Pets pet = new Pets(NameTextBox.Text, TypeTextBox.Text, int.Parse(AgeTextBox.Text));
                MessageBox.Show(pet.PetInfoString());
            
            }
            catch
            {
                MessageBox.Show("Invalid Input!\nPlease enter correct format and try again.");
            }
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();

        }
    }
}
