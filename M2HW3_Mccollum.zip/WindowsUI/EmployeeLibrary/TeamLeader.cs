﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class TeamLeader : ProductionWorker
    {
        public TeamLeader()
        {
            MonthlyBonus = 0.0m;
            RequiredTraining = 0;
            TrainingHours = 0;
        }

        public decimal MonthlyBonus { get; set; }
        public int RequiredTraining { get; set; }
        public int TrainingHours { get; set; }

    }
}
