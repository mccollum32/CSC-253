﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        //Constructor type
        public Employee()
        {
            //Values
            Name = "";
            IDnum = 0;
        }
        private int idNum;
        //Property values
        public string Name { get; set; }
        public int IDnum { get; set; }
    }
}
