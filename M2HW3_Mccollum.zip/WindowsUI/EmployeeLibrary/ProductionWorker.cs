﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class ProductionWorker : Employee
    {
        public ProductionWorker()
        {

            shift = 0;
            PayRate = 0.0m;
        }
        
        private int shift;

        public int Shift 
        { 
            get { return shift; }
            set 
            {
                if (value == 1 || value == 2 || value == 3)
                {
                   shift = value;
                }
                else
                {
                     value = 1;
                }
            }
        }
        public decimal PayRate { get; set; }
    }
}
