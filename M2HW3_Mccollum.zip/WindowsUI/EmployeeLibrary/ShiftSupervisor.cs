﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class ShiftSupervisor : Employee
    {
        public ShiftSupervisor() 
        {

            annualSalary = 0.0m;
            annualProduction = 0.0m;
        }

        public decimal annualSalary { get; set; }
        public decimal annualProduction { get; set; }
    }
}
