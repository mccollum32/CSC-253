﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GasLibrary1
{
    public class GasPriceOperations
    {
        public static List<GasPrices> ReadGasPrice()
        {

            List<GasPrices> price = new List<GasPrices>();

            using (StreamReader reader = File.OpenText(@"../../../GasLibrary1/GasText.txt"))
            {
                while (!reader.EndOfStream)
                {
                    string[] token = reader.ReadLine().Split(':');
                    price.Add(new GasPrices(DateTime.Parse(token[0]), double.Parse(token[1])));

                }
            }
            return price;

        }

        public static double AveragePriceYear(int year)
        {
        
            List<GasPrices> gasPrice = ReadGasPrice();

            Predicate<GasPrices> yearSplit = x => x.Date.Year != year;

            gasPrice.RemoveAll(yearSplit); 

            List<double> prices = PriceListed(gasPrice); 

            return prices.Average(); 

        }

        public static double AveragePriceMonth(int month, int year = -1)
        {


            Predicate<GasPrices> yearSplit = x => x.Date.Year != year; 
            Predicate<GasPrices> monthSplit = x => x.Date.Month != month; 

            List<GasPrices> gasPrices = ReadGasPrice();

            if (year != -1) gasPrices.RemoveAll(yearSplit); 

            gasPrices.RemoveAll(monthSplit); 
            List<double> prices = PriceListed(gasPrices); 

            return prices.Average();               

        }

        public static GasPrices HighPrice()
        {
            

            List<GasPrices> gasPrices = ReadGasPrice();

            List<double> prices = PriceListed(gasPrices);

            double maxPrice = prices.Max();

            Predicate<GasPrices> hasMaxValue = x => x.Price == maxPrice;

            return gasPrices.ElementAt(gasPrices.FindIndex(hasMaxValue));

        }

        public static GasPrices LowPrice()
        {

            List<GasPrices> gasPrices = ReadGasPrice();

            List<double> prices = PriceListed(gasPrices);

            double minPrice = prices.Min();

            Predicate<GasPrices> hasMinValue = x => x.Price == minPrice;

            return gasPrices.ElementAt(gasPrices.FindIndex(hasMinValue));

        }

        public static void AscendingFile()
        {
            StreamWriter outputFile;

            outputFile = File.CreateText(@"..\..\..\GasLibrary1\Results\Ascend\AscendingResults.txt");

            List<GasPrices> gasPrices = ReadGasPrice().OrderBy(gasPrice => gasPrice.Price).ToList();

            foreach (GasPrices gasPrice in gasPrices)
            {
                outputFile.WriteLine($"{gasPrice.Date.ToString("d")}:{gasPrice.Price}");
            }

            outputFile.Close();

        }

        public static void DescendingFile()
        {
            StreamWriter outputFile;

            outputFile = File.CreateText(@"..\..\..\GasLibrary1\Results\Descend\DescendingResults.txt");

            List<GasPrices> gasPrices = ReadGasPrice().OrderByDescending(gasPrice => gasPrice.Price).ToList();

            foreach (GasPrices gasPrice in gasPrices)
            {
                outputFile.WriteLine($"{gasPrice.Date.ToString("d")}:{gasPrice.Price}");
            }

            outputFile.Close();

        }

        private static List<double> PriceListed(List<GasPrices> gasPrices)
        {
            List<double> prices = new List<double>();

            for (int i = 0; i < gasPrices.Count; i++)
            {
                prices.Add(gasPrices.ElementAt(i).Price);
            }

            return prices;

        }

    }
}