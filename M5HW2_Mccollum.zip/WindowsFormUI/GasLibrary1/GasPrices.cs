﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GasLibrary1
{
    public class GasPrices
    {
    
        public DateTime Date { get; set; }
        public double Price { get; set; }



        public GasPrices() { } 

        public GasPrices(DateTime date, double price)
        {
            Date = date;
            Price = price;
        }
    }
}
