﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GasLibrary1;

/**
* 11/24/2023
* CSC 253
* Mccollum Joseph
* This program reads the date and price values from a text file also writes the files to a text documnet when the user promps the app to .
*/

namespace Gasprices
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show(GasPriceOperations.AveragePriceYear(int.Parse(textBox1.Text)).ToString());

            }
            catch
            {
                MessageBox.Show("Invalid option.\nTry again!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int year = (textBox2.Text != "") ? int.Parse(textBox2.Text) : -1;
                MessageBox.Show(GasPriceOperations.AveragePriceMonth(int.Parse(textBox2.Text), year).ToString());

            }
            catch
            {
                MessageBox.Show("Invalid option.\nTry again!");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            GasPrices highestPrice = GasPriceOperations.HighPrice();
            MessageBox.Show($"Date: {highestPrice.Date.ToString("d")}, Price: {highestPrice.Price}");            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            checkBox1.Checked = false;
            checkBox2.Checked = false;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            GasPrices lowestPrice = GasPriceOperations.LowPrice();
            MessageBox.Show($"Date: {lowestPrice.Date.ToString("d")}, Price: {lowestPrice.Price}");
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            GasPriceOperations.AscendingFile();
            MessageBox.Show("Text file created\nResults Folder.");
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            GasPriceOperations.DescendingFile();
            MessageBox.Show("Text file created\nResults Folder.");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox3.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
